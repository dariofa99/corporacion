
$( document ).ready(function() {

$(document).ajaxStart(function() {
  
  });
  $(document).ajaxStop(function() {
   
    
});



$('body').on('change', function () {



});



});